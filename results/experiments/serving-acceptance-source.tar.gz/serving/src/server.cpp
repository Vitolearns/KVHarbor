#include "kvharbor/serving/runtime.hpp"

#include <utility>
#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/version.hpp>

#include <algorithm>
#include <array>
#include <charconv>
#include <condition_variable>
#include <csignal>
#include <deque>
#include <iostream>
#include <map>
#include <mutex>
#include <optional>
#include <stdexcept>

namespace net = boost::asio;
namespace beast = boost::beast;
namespace http = beast::http;
using tcp = net::ip::tcp;
using Error = boost::system::error_code;
using namespace std::chrono_literals;
using namespace kvharbor::serving;
static_assert(BOOST_VERSION >= 108300, "KVHarbor serving requires Boost 1.83 or newer");

namespace {
struct Options {
    RuntimeConfig runtime;
    std::string bind = "127.0.0.1";
    int port = 8082, workers = 1, queue = 8, connections = 128;
    int timeout_ms = 60000, buffer_bytes = 65536, write_ms = 3000;
    bool fake = false, earliest_deadline = false;
};

int integer(std::string_view value, int lo, int hi) {
    int n=0;
    auto [end,ec]=std::from_chars(value.data(),value.data()+value.size(),n);
    if (ec!=std::errc{} || end!=value.data()+value.size() || n<lo || n>hi)
        throw std::invalid_argument("numeric option out of range");
    return n;
}

Options parse(int argc, char** argv) {
    Options o;
    for (int i=1; i<argc; ++i) {
        std::string a=argv[i];
        auto val=[&] { if (++i>=argc) throw std::invalid_argument("missing value for "+a); return std::string(argv[i]); };
        if (a=="--model") o.runtime.model=val();
        else if (a=="--model-id") o.runtime.model_id=val();
        else if (a=="--context") o.runtime.context=integer(val(),128,32768);
        else if (a=="--threads") o.runtime.threads=integer(val(),1,128);
        else if (a=="--gpu-layers") o.runtime.gpu_layers=integer(val(),0,999);
        else if (a=="--batch") o.runtime.batch=integer(val(),1,4096);
        else if (a=="--prefill-chunk") o.runtime.prefill_chunk=integer(val(),1,4096);
        else if (a=="--engine-schedule") {
            auto mode=val();
            if (mode=="fifo") o.runtime.engine_schedule=EngineSchedule::fifo;
            else if (mode=="decode-first") o.runtime.engine_schedule=EngineSchedule::decode_first;
            else if (mode=="off") o.runtime.engine_schedule=EngineSchedule::off;
            else throw std::invalid_argument("engine schedule must be off, fifo or decode-first");
        }
        else if (a=="--max-output-rows") o.runtime.max_output_rows=integer(val(),0,1);
        else if (a=="--reuse-context") o.runtime.reuse_context=true;
        else if (a=="--sampling") o.runtime.sampling=parse_sampling_mode(val());
        else if (a=="--asr-model-dir") o.runtime.asr_dir=val();
        else if (a=="--tts-model-dir") o.runtime.tts_dir=val();
        else if (a=="--bind") o.bind=val();
        else if (a=="--port") o.port=integer(val(),1,65535);
        else if (a=="--workers") o.workers=integer(val(),1,16);
        else if (a=="--queue") o.queue=integer(val(),0,256);
        else if (a=="--max-connections") o.connections=integer(val(),1,4096);
        else if (a=="--timeout-ms") o.timeout_ms=integer(val(),10,300000);
        else if (a=="--stream-buffer-bytes") o.buffer_bytes=integer(val(),1024,1024*1024);
        else if (a=="--write-timeout-ms") o.write_ms=integer(val(),10,30000);
        else if (a=="--policy") {
            auto policy=val();
            if (policy!="fifo" && policy!="deadline") throw std::invalid_argument("policy must be fifo or deadline");
            o.earliest_deadline=policy=="deadline";
        } else if (a=="--test-backend") o.fake=true;
        else throw std::invalid_argument("unknown option: "+a);
    }
    if (o.runtime.prefill_chunk>o.runtime.batch)
        throw std::invalid_argument("prefill chunk cannot exceed batch size");
    if (!o.fake && o.runtime.model.empty()) throw std::invalid_argument("--model is required");
    return o;
}

// The reactor owns the timer. Producers may wait for capacity, and cancellation
// wakes them. Bytes remain charged until the corresponding socket write finishes.
class Pipe : public std::enable_shared_from_this<Pipe> {
    net::any_io_executor executor_;
    net::steady_timer signal_;
    std::mutex mutex_;
    std::condition_variable space_;
    std::deque<std::shared_ptr<const std::string>> chunks_;
    std::size_t bytes_=0, peak_=0, cap_;
    bool stopped_=false, saturated_=false;
    std::chrono::milliseconds wait_limit_;
public:
    Pipe(net::io_context& io, std::size_t cap, std::chrono::milliseconds wait_limit):
        executor_(io.get_executor()), signal_(io), cap_(cap), wait_limit_(wait_limit) {}
    void notify() { signal_.cancel(); }
    net::awaitable<void> wait() {
        signal_.expires_at(Clock::time_point::max());
        Error ec;
        co_await signal_.async_wait(net::redirect_error(net::use_awaitable,ec));
    }
    bool put(std::string chunk, const Request& r) {
        std::unique_lock lock(mutex_);
        if (chunk.empty()) return !stopped_;
        if (chunk.size()>cap_) { saturated_=true; return false; }
        auto available=[&] { return stopped_ || r.cancelled->load() || chunk.size()<=cap_-bytes_; };
        if (!space_.wait_until(lock,std::min(r.deadline,Clock::now()+wait_limit_),available)) {
            saturated_=Clock::now()<r.deadline;
            return false;
        }
        if (stopped_ || r.cancelled->load() || Clock::now()>=r.deadline) return false;
        bool wake=chunks_.empty();
        bytes_+=chunk.size();
        peak_=std::max(peak_,bytes_);
        chunks_.push_back(std::make_shared<const std::string>(std::move(chunk)));
        lock.unlock();
        if (wake) net::post(executor_,[self=shared_from_this()] { self->notify(); });
        return true;
    }
    std::shared_ptr<const std::string> front() {
        std::lock_guard lock(mutex_);
        return chunks_.empty()?nullptr:chunks_.front();
    }
    void consumed() {
        std::lock_guard lock(mutex_);
        if (chunks_.empty()) return;
        bytes_-=chunks_.front()->size();
        chunks_.pop_front();
        space_.notify_one();
    }
    void stop() {
        {
            std::lock_guard lock(mutex_);
            stopped_=true;
            chunks_.clear(); bytes_=0;
        }
        space_.notify_all(); notify();
    }
    std::size_t peak() { std::lock_guard lock(mutex_); return peak_; }
    bool saturated() { std::lock_guard lock(mutex_); return saturated_; }
};

struct Job {
    Request request;
    std::shared_ptr<Pipe> pipe;
    std::optional<Clock::time_point> started;
    std::optional<Result> result;
    std::string stop_reason;
};

struct Slot {
    Task task;
    std::unique_ptr<Runtime> runtime;
    std::shared_ptr<Job> job;
};

class Admission {
    net::io_context& io_;
    const Options& options_;
    std::vector<Slot> slots_;
    net::thread_pool pool_;
    std::array<std::deque<std::shared_ptr<Job>>,3> queues_;
    std::map<std::string,std::uint64_t> outcomes_;
    std::uint64_t accepted_=0, started_=0, rejected_=0, releases_=0, serial_=0;
    std::size_t peak_buffer_=0;
    bool draining_=false;
    Json runtime_info_=Json::object();

    void complete(const std::shared_ptr<Job>& job, Result result) {
        if (job->result) throw std::logic_error("duplicate backend completion");
        if (!job->stop_reason.empty()) result.outcome=job->stop_reason;
        else if (job->pipe->saturated()) result.outcome="backpressure";
        else if (result.outcome=="cancelled" && Clock::now()>=job->request.deadline) result.outcome="deadline";
        ++outcomes_[result.outcome];
        peak_buffer_=std::max(peak_buffer_,job->pipe->peak());
        auto details=result.details;
        details.erase("token_ids"); details.erase("text");
        Json record={{"id",job->request.id},{"task",name(job->request.task)},{"outcome",result.outcome},
            {"queue_ms",job->started ? elapsed_ms(job->request.received,*job->started) : elapsed_ms(job->request.received)},
            {"backend_finished_ms",elapsed_ms(job->request.received)},{"slot_released",bool(job->started)},
            {"peak_buffer_bytes",job->pipe->peak()},{"usage",result.usage},{"timings",result.timings},{"details",details}};
        std::cout<<record.dump()<<'\n'<<std::flush;
        job->result=std::move(result);
        job->pipe->notify();
    }

    void start(std::size_t index, std::shared_ptr<Job> job) {
        auto& slot=slots_[index];
        slot.job=job;
        job->started=Clock::now();
        ++started_;
        job->pipe->notify();
        net::post(pool_,[this,index,job] {
            Result result;
            try {
                result=slots_[index].runtime->generate(job->request,[&](std::string chunk) {
                    return job->pipe->put(std::move(chunk),job->request);
                });
            } catch (const std::invalid_argument& e) {
                result.outcome="bad_request"; result.error=e.what();
            } catch (const Json::exception&) {
                result.outcome="bad_request"; result.error="invalid request fields";
            } catch (const std::exception& e) {
                result.outcome="failed"; result.error="native execution failed";
                std::cerr<<"runtime request "<<job->request.id<<": "<<e.what()<<'\n';
            } catch (...) {
                result.outcome="failed"; result.error="unknown runtime failure";
            }
            net::post(io_,[this,index,job,result=std::move(result)]() mutable {
                slots_[index].job.reset();
                ++releases_;
                complete(job,std::move(result));
                dispatch();
                if (draining_ && active()==0 && on_drained) on_drained();
            });
        });
    }

    void dispatch() {
        if (draining_) return;
        for (std::size_t i=0;i<slots_.size();++i) {
            if (slots_[i].job) continue;
            auto& queue=queues_[static_cast<int>(slots_[i].task)];
            while (!queue.empty()) {
                auto it=options_.earliest_deadline ? std::min_element(queue.begin(),queue.end(),[](const auto& a,const auto& b) {
                    return a->request.deadline < b->request.deadline;
                }) : queue.begin();
                auto job=std::move(*it); queue.erase(it);
                if (Clock::now()>=job->request.deadline) {
                    Result res; res.outcome="deadline"; complete(job,std::move(res));
                    continue;
                }
                start(i,std::move(job)); break;
            }
        }
    }
public:
    std::function<void()> on_drained;
    Admission(net::io_context& io, const Options& options, Factory& factory):
        io_(io), options_(options), pool_(options.workers+int(factory.available(Task::asr))+int(factory.available(Task::tts))) {
        for (auto task : {Task::llm,Task::asr,Task::tts}) {
            if (!factory.available(task)) continue;
            int n=task==Task::llm?options.workers:1;
            for (int i=0;i<n;++i) slots_.push_back({task,factory.worker(task),nullptr});
            runtime_info_[name(task)]=slots_.back().runtime->info();
        }
    }
    ~Admission() { pool_.join(); }
    bool supports(Task task) const { return runtime_info_.contains(name(task)); }
    const Json& info() const { return runtime_info_; }
    std::string next_id() { return "kvh-"+std::to_string(++serial_); }
    std::size_t active() const { return std::count_if(slots_.begin(),slots_.end(),[](const auto& s){return bool(s.job);}); }
    bool submit(const std::shared_ptr<Job>& job) {
        if (draining_) { ++rejected_; return false; }
        for (std::size_t i=0;i<slots_.size();++i) {
            if (slots_[i].task==job->request.task && !slots_[i].job) {
                ++accepted_; start(i,job); return true;
            }
        }
        auto& queue=queues_[static_cast<int>(job->request.task)];
        if (queue.size()>=static_cast<std::size_t>(options_.queue)) { ++rejected_; return false; }
        ++accepted_; queue.push_back(job); return true;
    }
    void cancel(const std::shared_ptr<Job>& job, std::string reason) {
        if (!job) return;
        if (job->stop_reason.empty()) job->stop_reason=std::move(reason);
        job->request.cancelled->store(true);
        job->pipe->stop();
        if (job->result || job->started) return;
        auto& queue=queues_[static_cast<int>(job->request.task)];
        auto it=std::find(queue.begin(),queue.end(),job);
        if (it!=queue.end()) {
            queue.erase(it);
            Result res; res.outcome=job->stop_reason;
            complete(job,std::move(res));
        }
    }
    void shutdown() {
        draining_=true;
        for (auto& q:queues_) while (!q.empty()) { auto job=q.front(); cancel(job,"shutdown"); }
        for (auto& slot:slots_) if (slot.job) cancel(slot.job,"shutdown");
        if (active()==0 && on_drained) on_drained();
    }
    Json snapshot() const {
        Json tasks=Json::object();
        for (auto t:{Task::llm,Task::asr,Task::tts}) {
            std::size_t busy=0, limit=0;
            for (const auto& s:slots_) if (s.task==t) { ++limit; busy+=bool(s.job); }
            tasks[name(t)]={{"active",busy},{"slots",limit},{"queued",queues_[static_cast<int>(t)].size()}};
        }
        return {{"accepted",accepted_},{"started",started_},{"rejected",rejected_},{"slot_releases",releases_},
            {"active",active()},{"outcomes",outcomes_},{"peak_buffer_bytes",peak_buffer_},
            {"tasks",tasks},{"draining",draining_}};
    }
    std::string metrics() const {
        auto s=snapshot();
        std::string text;
        for (auto key:{"accepted","started","rejected","slot_releases","active","peak_buffer_bytes"})
            text+="kvharbor_"+std::string(key)+" "+s.at(key).dump()+"\n";
        for (auto& [key,value]:s.at("outcomes").items())
            text+="kvharbor_backend_outcomes_total{outcome=\""+key+"\"} "+value.dump()+"\n";
        for (auto& [task,value]:s.at("tasks").items()) for (auto key:{"active","queued","slots"})
            text+="kvharbor_task_"+std::string(key)+"{task=\""+task+"\"} "+value.at(key).dump()+"\n";
        return text;
    }
};

struct Client {
    beast::tcp_stream stream;
    net::steady_timer deadline;
    std::shared_ptr<Job> job;
    std::array<char,1> watch{};
    bool closed=false, header_sent=false;
    Client(tcp::socket socket, net::io_context& io): stream(std::move(socket)), deadline(io) {}
    void close() {
        if (closed) return;
        closed=true;
        deadline.cancel();
        Error ec;
        stream.socket().close(ec);
    }
};

net::awaitable<void> reply(Client& client, http::status status, std::string body, std::string type="application/json") {
    http::response<http::string_body> message{status,11};
    message.set(http::field::content_type,type);
    message.keep_alive(false);
    if (client.job) message.set("X-Request-Id",client.job->request.id);
    message.body()=std::move(body); message.prepare_payload();
    client.stream.expires_after(3s);
    Error ec;
    co_await http::async_write(client.stream,message,net::redirect_error(net::use_awaitable,ec));
}

std::string error_body(const std::string& text) { return Json{{"error",{{"message",text}}}}.dump(); }

net::awaitable<void> serve(std::shared_ptr<Client> client, net::io_context& io, Admission& admission, const Options& options) {
    auto& stream=client->stream;
    beast::flat_buffer read_buffer(2*1024*1024+16384);
    http::request_parser<http::string_body> parser;
    parser.header_limit(16384); parser.body_limit(2*1024*1024);
    stream.expires_after(5s);
    Error ec;
    co_await http::async_read(stream,read_buffer,parser,net::redirect_error(net::use_awaitable,ec));
    if (ec) {
        if (ec==http::error::body_limit) co_await reply(*client,http::status::payload_too_large,error_body("request body exceeds 2 MiB"));
        co_return;
    }
    auto req=parser.release();
    if (req.method()==http::verb::get) {
        std::string body, type="application/json";
        auto status=http::status::ok;
        if (req.target()=="/health") body=Json{{"status","ok"},{"runtimes",admission.info()}}.dump();
        else if (req.target()=="/state") body=admission.snapshot().dump();
        else if (req.target()=="/metrics") { body=admission.metrics(); type="text/plain; version=0.0.4"; }
        else if (req.target()=="/v1/models") body=Json{{"object","list"},
            {"data",Json::array({{{"id",options.runtime.model_id},{"object","model"}}})}}.dump();
        else { status=http::status::not_found; body=error_body("unknown endpoint"); }
        co_await reply(*client,status,std::move(body),std::move(type));
        co_return;
    }
    Task task=Task::llm;
    if (req.target()=="/v1/audio/transcriptions") task=Task::asr;
    else if (req.target()=="/v1/audio/speech") task=Task::tts;
    else if (req.target()!="/v1/chat/completions" && req.target()!="/v1/completions") {
        co_await reply(*client,http::status::not_found,error_body("unknown endpoint")); co_return;
    }
    if (req.method()!=http::verb::post) { co_await reply(*client,http::status::method_not_allowed,error_body("expected POST")); co_return; }
    if (!admission.supports(task)) { co_await reply(*client,http::status::service_unavailable,error_body("task runtime is unavailable")); co_return; }
    auto job=std::make_shared<Job>();
    job->request.task=task;
    job->request.id=admission.next_id();
    job->pipe=std::make_shared<Pipe>(io,options.buffer_bytes,std::chrono::milliseconds(options.write_ms));
    std::string error;
    try {
        auto timeout=options.timeout_ms;
        auto header=req.find("X-Request-Timeout-Ms");
        if (header!=req.end()) timeout=std::min(timeout,integer({header->value().data(),header->value().size()},10,300000));
        job->request.deadline=job->request.received+std::chrono::milliseconds(timeout);
        if (task==Task::asr) {
            if (!req[http::field::content_type].starts_with("audio/wav")) throw std::invalid_argument("expected audio/wav");
            job->request.audio=std::move(req.body());
        } else {
            job->request.body=Json::parse(req.body());
            if (!job->request.body.is_object()) throw std::invalid_argument("expected JSON object");
            if (task==Task::llm && !job->request.body.value("stream",false)) throw std::invalid_argument("stream=true required");
        }
    } catch (const std::exception&) { error="invalid body, content type or deadline"; }
    if (!error.empty()) { co_await reply(*client,http::status::bad_request,error_body(error)); co_return; }
    if (!admission.submit(job)) { co_await reply(*client,http::status::too_many_requests,error_body("task queue is full")); co_return; }
    client->job=job;
    client->deadline.expires_at(job->request.deadline);
    client->deadline.async_wait([client,job,&admission](Error e) {
        if (e || client->closed) return;
        admission.cancel(job,"deadline");
        if (client->header_sent) client->close();
    });
    // There is no HTTP pipelining on this connection. An EOF/reset (or extra
    // input) cancels the model request independently of blocked response writes.
    stream.socket().async_read_some(net::buffer(client->watch),[client,job,&admission](Error e,std::size_t) {
        if (!client->closed && e!=net::error::operation_aborted) {
            admission.cancel(job,"client_disconnected"); client->close();
        }
    });

    while (!client->closed && !job->result && !job->request.cancelled->load() && (task==Task::asr || !job->pipe->front()))
        co_await job->pipe->wait();
    if (client->closed) co_return;
    if (job->request.cancelled->load() || (job->result && job->result->outcome!="completed")) {
        bool timeout=job->stop_reason=="deadline" || (job->result && job->result->outcome=="deadline");
        auto status=timeout?http::status::request_timeout:job->result && job->result->outcome=="bad_request"?
            http::status::bad_request:http::status::bad_gateway;
        co_await reply(*client,status,error_body(timeout?"request deadline exceeded":job->result?job->result->error:"request cancelled"));
        co_return;
    }
    if (task==Task::asr) {
        auto body=Json{{"id",job->request.id},{"text",job->result->details.at("text")},
            {"timings",job->result->timings},{"audio_seconds",job->result->details.at("audio_seconds")}}.dump();
        co_await reply(*client,http::status::ok,std::move(body));
        co_return;
    }

    http::response<http::empty_body> header{http::status::ok,11};
    header.keep_alive(false); header.chunked(true);
    header.set(http::field::content_type,task==Task::llm?"text/event-stream":"audio/pcm");
    header.set(http::field::cache_control,"no-cache");
    header.set("X-Request-Id",job->request.id);
    if (task==Task::tts) {
        header.set("X-Audio-Sample-Rate",admission.info().at("tts").at("sample_rate").dump());
        header.set("X-Audio-Encoding","pcm_s16le_mono");
    }
    http::response_serializer<http::empty_body> serializer(header);
    client->header_sent=true;
    stream.expires_after(std::chrono::milliseconds(options.write_ms));
    co_await http::async_write_header(stream,serializer,net::redirect_error(net::use_awaitable,ec));
    if (ec) { admission.cancel(job,"client_write_failed"); co_return; }
    while (!client->closed && !job->request.cancelled->load()) {
        if (auto chunk=job->pipe->front()) {
            stream.expires_after(std::chrono::milliseconds(options.write_ms));
            auto wire=http::make_chunk(net::buffer(*chunk));
            co_await net::async_write(stream,wire,net::redirect_error(net::use_awaitable,ec));
            if (ec) { admission.cancel(job,"client_write_failed"); co_return; }
            job->pipe->consumed();
        } else if (job->result) break;
        else co_await job->pipe->wait();
    }
    if (client->closed || job->request.cancelled->load()) co_return;
    if (task==Task::llm) {
        std::string tail;
        if (job->result->outcome=="completed") {
            auto finish=job->result->details.value("finish_reason","stop");
            tail="data: "+Json{{"id",job->request.id},{"choices",Json::array({{{"index",0},{"delta",Json::object()},
                {"finish_reason",finish}}})},{"usage",job->result->usage}}.dump()+"\n\ndata: [DONE]\n\n";
        } else tail="data: "+error_body(job->result->error.empty()?job->result->outcome:job->result->error)+"\n\n";
        stream.expires_after(std::chrono::milliseconds(options.write_ms));
        auto wire=http::make_chunk(net::buffer(tail));
        co_await net::async_write(stream,wire,net::redirect_error(net::use_awaitable,ec));
        if (ec) co_return;
    } else if (job->result->outcome!="completed") co_return; // Truncated PCM never claims normal completion.
    stream.expires_after(std::chrono::milliseconds(options.write_ms));
    auto last=http::make_chunk_last();
    co_await net::async_write(stream,last,net::redirect_error(net::use_awaitable,ec));
}
}

int main(int argc, char** argv) try {
    auto options=parse(argc,argv);
    auto factory=make_factory(options.runtime,options.fake);
    net::io_context io(1);
    auto work=net::make_work_guard(io);
    Admission admission(io,options,*factory);
    tcp::acceptor acceptor(io,{net::ip::make_address(options.bind),static_cast<unsigned short>(options.port)});
    std::map<Client*,std::shared_ptr<Client>> clients;
    net::signal_set signals(io,SIGINT,SIGTERM);
    admission.on_drained=[&] { work.reset(); };
    signals.async_wait([&](Error e,int) {
        if (e) return;
        Error ignored;
        acceptor.close(ignored);
        admission.shutdown();
        for (auto& [_,c]:clients) c->close();
    });
    auto accept=[&]() -> net::awaitable<void> {
        while (acceptor.is_open()) {
            Error e;
            auto socket=co_await acceptor.async_accept(net::redirect_error(net::use_awaitable,e));
            if (e) break;
            if (clients.size()>=static_cast<std::size_t>(options.connections)) continue;
            Error ignored;
            socket.set_option(tcp::no_delay(true),ignored);
            auto client=std::make_shared<Client>(std::move(socket),io);
            clients[client.get()]=client;
            net::co_spawn(io,serve(client,io,admission,options),[&,client](std::exception_ptr exception) {
                if (exception) {
                    admission.cancel(client->job,"internal_error");
                    try { std::rethrow_exception(exception); }
                    catch (const std::exception& error) { std::cerr<<"request: "<<error.what()<<'\n'; }
                }
                client->close(); clients.erase(client.get());
            });
        }
    };
    net::co_spawn(io,accept(),[&](std::exception_ptr e) {
        if (e) { std::cerr<<"accept loop failed\n"; signals.cancel(); admission.shutdown(); }
    });
    std::cout<<Json{{"listening",options.bind+":"+std::to_string(options.port)},{"runtimes",admission.info()},
        {"policy",options.earliest_deadline?"deadline":"fifo"},{"queue_per_task",options.queue},
        {"stream_buffer_bytes",options.buffer_bytes}}.dump()<<'\n'<<std::flush;
    io.run();
    std::cout<<Json{{"shutdown",admission.snapshot()}}.dump()<<'\n';
    return 0;
} catch (const std::exception& error) {
    std::cerr<<"kvharbor-server: "<<error.what()<<'\n';
    return 1;
}
