#include "engine_schedule.hpp"
#include "kvharbor/serving/runtime.hpp"

#include <ggml-backend.h>
#include <llama.h>

#include <algorithm>
#include <array>
#include <limits>
#include <mutex>
#include <stdexcept>
#include <utility>

namespace kvharbor::serving {
namespace {
struct ModelDeleter { void operator()(llama_model* p) const { if (p) llama_model_free(p); } };
struct ContextDeleter { void operator()(llama_context* p) const { if (p) llama_free(p); } };
struct SamplerDeleter { void operator()(llama_sampler* p) const { if (p) llama_sampler_free(p); } };
using Model = std::shared_ptr<llama_model>;
using Context = std::unique_ptr<llama_context, ContextDeleter>;
using Sampler = std::unique_ptr<llama_sampler, SamplerDeleter>;

Sampler greedy_chain() {
    auto params=llama_sampler_chain_default_params();
    params.no_perf=true;
    Sampler chain(llama_sampler_chain_init(params));
    Sampler greedy(llama_sampler_init_greedy());
    if (!chain || !greedy) throw std::runtime_error("greedy chain allocation failed");
    llama_sampler_chain_add(chain.get(),greedy.release());
    return chain;
}

std::string prompt_for(const Json& body) {
    if (body.contains("prompt")) return body.at("prompt").get<std::string>();
    const auto& messages = body.at("messages");
    if (!messages.is_array() || messages.empty() || messages.size()>64)
        throw std::invalid_argument("messages must contain 1 to 64 text messages");
    std::vector<std::pair<std::string,std::string>> owned;
    for (const auto& message : messages) {
        auto role = message.at("role").get<std::string>();
        if (role!="system" && role!="user" && role!="assistant")
            throw std::invalid_argument("only system, user and assistant roles supported");
        owned.emplace_back(std::move(role), message.at("content").get<std::string>());
    }
    std::vector<llama_chat_message> view;
    for (const auto& [role,content] : owned) view.push_back({role.c_str(),content.c_str()});
    // The first native adapter explicitly supports the text-only ChatML dialect.
    // Prefix the configured Qwen model's non-thinking assistant turn.
    std::string result(4096,'\0');
    int n = llama_chat_apply_template("chatml", view.data(), view.size(), true, result.data(), result.size());
    if (n <= 0 || n > 1024*1024) throw std::invalid_argument("chat template output exceeds limit");
    if (static_cast<std::size_t>(n) > result.size()) {
        result.resize(n);
        int again = llama_chat_apply_template("chatml", view.data(), view.size(), true, result.data(), result.size());
        if (again != n) throw std::runtime_error("chat template changed on retry");
    }
    result.resize(n);
    result += "<think>\n\n</think>\n\n";
    return result;
}

std::vector<llama_token> tokenize(const llama_vocab* vocab, const std::string& prompt, int limit) {
    if (prompt.empty() || prompt.size()>1024*1024 || limit<1)
        throw std::invalid_argument("prompt or output budget is invalid");
    // One tokenizer pass in the common case; the negative return carries the required size.
    std::vector<llama_token> out(limit);
    auto n = llama_tokenize(vocab, prompt.data(), static_cast<int>(prompt.size()), out.data(), limit, true, true);
    if (n <= 0 || n > limit) throw std::invalid_argument("prompt plus max_tokens exceeds context");
    out.resize(n);
    return out;
}

std::string render(const llama_vocab* vocab, llama_token token) {
    std::array<char, 128> small{};
    int n = llama_token_to_piece(vocab, token, small.data(), small.size(), 0, false);
    if (n >= 0) return std::string(small.data(), n);
    if (n < -65536) throw std::runtime_error("token piece too large");
    std::string piece(-n, '\0');
    n = llama_token_to_piece(vocab, token, piece.data(), piece.size(), 0, false);
    if (n < 0 || static_cast<std::size_t>(n)>piece.size()) throw std::runtime_error("token rendering failed");
    piece.resize(n);
    return piece;
}

class LlamaRuntime final : public Runtime {
    Model model_;
    RuntimeConfig config_;
    std::shared_ptr<EngineDispatch> dispatch_;
    const llama_vocab* vocab_;
    // A bound sampler must outlive every context referencing it (reverse destruction).
    Sampler backend_sampler_;
    Context retained_;
    const std::atomic<bool>* active_cancel_ = nullptr;
    std::size_t contexts_created_ = 0;

    static bool abort(void* data) {
        auto& self = *static_cast<LlamaRuntime*>(data);
        return self.active_cancel_ && self.active_cancel_->load(std::memory_order_relaxed);
    }

    Context create_context() {
        auto params = llama_context_default_params();
        params.n_ctx = config_.context;
        params.n_batch = std::min(config_.batch,config_.context);
        params.n_ubatch = params.n_batch;
        params.n_seq_max = 1;
        // This adapter requests only the last logits row in each decode call.
        params.n_outputs_max = config_.max_output_rows;
        params.n_threads = config_.threads;
        params.n_threads_batch = config_.threads;
        params.abort_callback = abort;
        params.abort_callback_data = this;
        params.no_perf = false;
        llama_sampler_seq_config binding{0,nullptr};
        if (config_.sampling==SamplingMode::backend) {
            if (!backend_sampler_) backend_sampler_=greedy_chain();
            binding.sampler=backend_sampler_.get();
            params.samplers=&binding;
            params.n_samplers=1;
        }
        Context ctx(llama_init_from_model(model_.get(), params));
        if (!ctx || llama_n_ctx_seq(ctx.get()) < static_cast<unsigned>(config_.context))
            throw std::runtime_error("llama context allocation failed");
        ++contexts_created_;
        return ctx;
    }

public:
    LlamaRuntime(Model model, RuntimeConfig config, std::shared_ptr<EngineDispatch> dispatch):
        model_(std::move(model)), config_(std::move(config)), dispatch_(std::move(dispatch)),
        vocab_(llama_model_get_vocab(model_.get())) {}

    Json info() const override {
        return {{"backend","llama.cpp"},{"model",config_.model_id},
            {"context",config_.context},{"threads",config_.threads},{"gpu_layers",config_.gpu_layers},
            {"batch",config_.batch},{"sequences_per_context",1},
            {"prefill_chunk",config_.prefill_chunk?config_.prefill_chunk:std::min(config_.batch,config_.context)},
            {"engine_schedule",config_.engine_schedule==EngineSchedule::off?"off":
                config_.engine_schedule==EngineSchedule::fifo?"fifo":"decode-first"},
            {"context_policy",config_.reuse_context?"reuse":"fresh"},
            {"max_output_rows_requested",config_.max_output_rows},
            {"sampling_mode",name(config_.sampling)},{"vocab_size",llama_vocab_n_tokens(vocab_)},
            {"sampling_implementation",config_.sampling==SamplingMode::direct?greedy_implementation():"llama.cpp"}};
    }

    Result generate(const Request& r, const Emit& emit) override {
        Result result;
        const auto begin = Clock::now();
        const int max_tokens = r.body.value("max_tokens",64);
        if (max_tokens<1 || max_tokens>=config_.context || r.body.value("temperature",0.0)!=0.0)
            throw std::invalid_argument("native adapter requires temperature=0 and a bounded max_tokens");
        if (r.body.value("model",config_.model_id)!=config_.model_id)
            throw std::invalid_argument("requested model is not loaded");
        auto tokens = tokenize(vocab_, prompt_for(r.body), config_.context-max_tokens);
        result.timings["template_tokenize_ms"] = elapsed_ms(begin);
        if (r.cancelled->load() || Clock::now()>=r.deadline) { result.outcome="cancelled"; return result; }

        // A worker lease covers context use through native completion. Abort data never outlives r.
        struct CancelScope {
            const std::atomic<bool>*& slot;
            ~CancelScope() { slot=nullptr; }
        } scope{active_cancel_};
        active_cancel_ = r.cancelled.get();
        Context fresh;
        auto phase = Clock::now();
        bool reused = config_.reuse_context && static_cast<bool>(retained_);
        if (config_.reuse_context && !retained_) retained_=create_context();
        if (!config_.reuse_context) fresh=create_context();
        auto* ctx = config_.reuse_context ? retained_.get() : fresh.get();
        result.timings["context_create_ms"] = reused ? 0.0 : elapsed_ms(phase);
        phase=Clock::now();
        if (reused) {
            // Reset both attention KV and recurrent state; no cross-request prompt cache.
            llama_memory_clear(llama_get_memory(ctx), true);
            llama_synchronize(ctx);
        }
        result.timings["context_reset_ms"]=elapsed_ms(phase);
        result.details={{"context_reused",reused},{"contexts_created_by_worker",contexts_created_},
            {"sampling_mode",name(config_.sampling)},{"vocab_size",llama_vocab_n_tokens(vocab_)},
            {"sampling_implementation",config_.sampling==SamplingMode::direct?greedy_implementation():"llama.cpp"}};
        if (config_.sampling==SamplingMode::backend) llama_sampler_reset(backend_sampler_.get());
        auto cancelled = [&] { return r.cancelled->load(std::memory_order_relaxed) || Clock::now()>=r.deadline; };
        EngineDispatch::Stats dispatch_stats;
        auto decode = [&](llama_token* input, int count, EngineDispatch::Phase work) {
            if (cancelled()) return false;
            auto on_engine = [&] {
                auto code = llama_decode(ctx, llama_batch_get_one(input,count));
                llama_synchronize(ctx);
                return code;
            };
            int rc;
            if (dispatch_) {
                auto scheduled = dispatch_->run(work, this, dispatch_stats, cancelled, on_engine);
                if (!scheduled) return false;
                rc = *scheduled;
            } else {
                rc = on_engine();
            }
            if (cancelled() || rc==2) return false;
            if (rc!=0) {
                // A failed context is discarded instead of being leased to another request.
                retained_.reset();
                throw std::runtime_error("llama_decode failed with status " + std::to_string(rc));
            }
            return true;
        };
        phase=Clock::now();
        const std::size_t batch = llama_n_batch(ctx);
        const std::size_t prefill_chunk = config_.prefill_chunk
            ? std::min<std::size_t>(config_.prefill_chunk, batch) : batch;
        for (std::size_t offset=0; offset<tokens.size();) {
            auto count=std::min(prefill_chunk,tokens.size()-offset);
            if (!decode(tokens.data()+offset,static_cast<int>(count),EngineDispatch::Phase::prefill)) {
                result.outcome="cancelled";
                return result;
            }
            offset += count;
        }
        result.timings["prefill_ms"]=elapsed_ms(phase);
        Sampler sampler;
        if (config_.sampling==SamplingMode::legacy) sampler.reset(llama_sampler_init_greedy());
        else if (config_.sampling==SamplingMode::chain) sampler=greedy_chain();
        if ((config_.sampling==SamplingMode::legacy || config_.sampling==SamplingMode::chain) && !sampler)
            throw std::runtime_error("greedy sampler allocation failed");
        const auto n_vocab=llama_vocab_n_tokens(vocab_);
        if (n_vocab<=0) throw std::runtime_error("invalid model vocabulary");
        std::size_t sample_calls=0, backend_samples=0;
        std::vector<llama_token> generated;
        std::string pending;
        double sampling_ms=0.0, decode_ms=0.0;
        for (int i=0;i<max_tokens;++i) {
            if (cancelled()) { result.outcome="cancelled"; break; }
            phase=Clock::now();
            llama_token token;
            if (config_.sampling==SamplingMode::direct) {
                const auto* logits=llama_get_logits_ith(ctx,-1);
                if (!logits) throw std::runtime_error("missing logits for direct greedy sampling");
                token=greedy_argmax({logits,static_cast<std::size_t>(n_vocab)});
            } else if (config_.sampling==SamplingMode::backend) {
                token=llama_get_sampled_token_ith(ctx,-1);
                if (token==LLAMA_TOKEN_NULL)
                    throw std::runtime_error("backend sampling unavailable; explicit mode never silently falls back");
                llama_sampler_accept(backend_sampler_.get(),token);
                ++backend_samples;
            } else token=llama_sampler_sample(sampler.get(),ctx,-1);
            ++sample_calls;
            sampling_ms += elapsed_ms(phase);
            if (llama_vocab_is_eog(vocab_,token)) break;
            generated.push_back(token);
            pending += render(vocab_,token);
            auto text=take_utf8(pending);
            if (!text.empty()) {
                if (!result.timings.contains("native_ttft_ms")) result.timings["native_ttft_ms"]=elapsed_ms(begin);
                if (!emit(sse_content(r.id,text))) { result.outcome="cancelled"; break; }
            }
            if (i+1==max_tokens) break;
            phase=Clock::now();
            if (!decode(&token,1,EngineDispatch::Phase::decode)) { result.outcome="cancelled"; break; }
            decode_ms += elapsed_ms(phase);
        }
        if (result.outcome=="completed") {
            auto tail=take_utf8(pending,true);
            if (!tail.empty() && !emit(sse_content(r.id,tail))) result.outcome="cancelled";
        }
        result.usage={{"prompt_tokens",tokens.size()},{"completion_tokens",generated.size()},
            {"total_tokens",tokens.size()+generated.size()}};
        result.details["token_ids"]=generated;
        result.details["sampling_calls"]=sample_calls;
        result.details["backend_sampled_tokens"]=backend_samples;
        result.details["cpu_candidate_rows_constructed"]=
            (config_.sampling==SamplingMode::legacy || config_.sampling==SamplingMode::chain) ? sample_calls*n_vocab : 0;
        result.details["finish_reason"]=generated.size()==static_cast<std::size_t>(max_tokens)?"length":"stop";
        result.timings["sampling_ms"]=sampling_ms;
        result.timings["decode_ms"]=decode_ms;
        result.timings["generation_ms"]=elapsed_ms(begin);
        // Include per-request context destruction in the measured worker occupancy.
        phase=Clock::now();
        fresh.reset();
        result.timings["context_free_ms"]=elapsed_ms(phase);
        if (dispatch_) {
            result.details["engine_schedule"] = {
                {"prefill_calls",dispatch_stats.prefill_calls},
                {"decode_calls",dispatch_stats.decode_calls},
                {"decode_ahead_of_prefill",dispatch_stats.decode_ahead_of_prefill},
                {"forced_prefill",dispatch_stats.forced_prefill},
                {"decode_after_other_prefill",dispatch_stats.decode_after_other_prefill},
                {"prefill_after_other_decode",dispatch_stats.prefill_after_other_decode},
                {"wait_us",dispatch_stats.wait_us},
            };
        }
        return result;
    }
};

class LlamaFactory final : public Factory {
    RuntimeConfig config_;
    Model model_;
    std::shared_ptr<EngineDispatch> dispatch_;
public:
    explicit LlamaFactory(RuntimeConfig config): config_(std::move(config)) {
        if (config_.context<128 || config_.context>32768 || config_.batch<1 || config_.threads<1)
            throw std::invalid_argument("invalid native runtime configuration");
        if (config_.prefill_chunk<0 || config_.prefill_chunk>config_.batch)
            throw std::invalid_argument("prefill chunk cannot exceed batch size");
        if (config_.engine_schedule!=EngineSchedule::off)
            dispatch_=std::make_shared<EngineDispatch>(config_.engine_schedule==EngineSchedule::decode_first);
        static std::once_flag backend;
        std::call_once(backend, [] { ggml_backend_load_all(); });
        auto params=llama_model_default_params();
        params.n_gpu_layers=config_.gpu_layers;
        params.load_mode=LLAMA_LOAD_MODE_MMAP;
        model_=Model(llama_model_load_from_file(config_.model.c_str(),params),ModelDeleter{});
        if (!model_ || !llama_model_has_decoder(model_.get()) || llama_model_has_encoder(model_.get()))
            throw std::runtime_error("failed to load decoder-only GGUF");
    }
    bool available(Task task) const override {
        if (task==Task::llm) return true;
#ifdef KVHARBOR_SERVING_AUDIO
        return task==Task::asr ? !config_.asr_dir.empty() : !config_.tts_dir.empty();
#else
        return false;
#endif
    }
    std::unique_ptr<Runtime> worker(Task task) override {
        switch (task) {
            case Task::llm: return std::make_unique<LlamaRuntime>(model_,config_,dispatch_);
            case Task::asr: return make_asr_runtime(config_);
            case Task::tts: return make_tts_runtime(config_);
        }
        throw std::logic_error("unknown task");
    }
};
}
std::unique_ptr<Factory> make_llama_factory(const RuntimeConfig& config) { return std::make_unique<LlamaFactory>(config); }
}
