#include "kvharbor/serving/runtime.hpp"

#include <sherpa-onnx/c-api/c-api.h>

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <stdexcept>

namespace kvharbor::serving {
namespace {
namespace fs = std::filesystem;
bool stopped(const Request& r) { return r.cancelled->load() || Clock::now()>=r.deadline; }

std::string asset(const fs::path& root, const std::string& path) {
    auto p=root/path;
    if (!fs::exists(p)) throw std::runtime_error("missing speech model asset: "+p.string());
    return p.string();
}

class AsrRuntime final : public Runtime {
    std::unique_ptr<const SherpaOnnxOfflineRecognizer,decltype(&SherpaOnnxDestroyOfflineRecognizer)>
        engine_{nullptr,SherpaOnnxDestroyOfflineRecognizer};
public:
    explicit AsrRuntime(const fs::path& root) {
        auto frontend=asset(root,"conv_frontend.onnx"), encoder=asset(root,"encoder.int8.onnx");
        auto decoder=asset(root,"decoder.int8.onnx"), tokenizer=asset(root,"tokenizer");
        SherpaOnnxOfflineRecognizerConfig config{};
        config.model_config.num_threads=2;
        config.model_config.provider="cpu";
        auto& q=config.model_config.qwen3_asr;
        q.conv_frontend=frontend.c_str(); q.encoder=encoder.c_str(); q.decoder=decoder.c_str(); q.tokenizer=tokenizer.c_str();
        q.max_total_len=512; q.max_new_tokens=128; q.temperature=1e-6f; q.top_p=0.8f; q.seed=42;
        engine_.reset(SherpaOnnxCreateOfflineRecognizer(&config));
        if (!engine_) throw std::runtime_error("failed to initialize Qwen3-ASR");
    }
    Json info() const override {
        return {{"backend","sherpa-onnx"},{"model","Qwen3-ASR-0.6B-int8"},{"device","cpu"},
            {"threads",2},{"streaming",false},{"cancel_mode","after_native_decode"}};
    }
    Result generate(const Request& r, const Emit&) override {
        Result result;
        auto phase=Clock::now();
        int rate=0;
        auto audio=read_pcm16_wav(r.audio,rate);
        const double seconds=static_cast<double>(audio.size())/rate;
        if (seconds>30) throw std::invalid_argument("ASR currently accepts at most 30 seconds of PCM16 mono WAV");
        result.timings["wav_parse_ms"]=elapsed_ms(phase);
        if (stopped(r)) { result.outcome="cancelled"; return result; }
        using Stream=std::unique_ptr<const SherpaOnnxOfflineStream,decltype(&SherpaOnnxDestroyOfflineStream)>;
        Stream stream(SherpaOnnxCreateOfflineStream(engine_.get()),SherpaOnnxDestroyOfflineStream);
        if (!stream) throw std::runtime_error("failed to allocate ASR stream");
        phase=Clock::now();
        SherpaOnnxAcceptWaveformOffline(stream.get(),rate,audio.data(),static_cast<int32_t>(audio.size()));
        result.timings["accept_waveform_ms"]=elapsed_ms(phase);
        if (stopped(r)) { result.outcome="cancelled"; return result; }
        phase=Clock::now();
        // The offline C API is blocking. Admission retains this worker lease
        // even if the HTTP request times out before native execution returns.
        SherpaOnnxDecodeOfflineStream(engine_.get(),stream.get());
        const double decode=elapsed_ms(phase);
        result.timings["decode_ms"]=decode;
        result.details={{"audio_seconds",seconds},{"rtf",decode/1000/seconds},{"sample_rate",rate}};
        if (stopped(r)) { result.outcome="cancelled"; return result; }
        using Output=std::unique_ptr<const SherpaOnnxOfflineRecognizerResult,decltype(&SherpaOnnxDestroyOfflineRecognizerResult)>;
        Output output(SherpaOnnxGetOfflineStreamResult(stream.get()),SherpaOnnxDestroyOfflineRecognizerResult);
        if (!output || !output->text) throw std::runtime_error("ASR returned no result");
        result.details["text"]=output->text;
        return result;
    }
};

class TtsRuntime final : public Runtime {
    std::unique_ptr<const SherpaOnnxOfflineTts,decltype(&SherpaOnnxDestroyOfflineTts)> engine_{nullptr,SherpaOnnxDestroyOfflineTts};
    int sample_rate_=0, speakers_=0;
    struct Callback {
        const Request& request;
        const Emit& emit;
        Clock::time_point start;
        std::size_t samples=0;
        double first_ms=-1;
        bool failed=false;
        int rate=0;
        static int32_t deliver(const float* samples, int32_t count, float, void* user) noexcept {
            auto& self=*static_cast<Callback*>(user);
            try {
                if (stopped(self.request)) return 0;
                if (!samples || count<0 || self.samples+static_cast<std::size_t>(count)>static_cast<std::size_t>(self.rate)*60) {
                    self.failed=true; return 0;
                }
                for (int32_t i=0;i<count;) {
                    const int32_t n=std::min<int32_t>(4096,count-i);
                    if (!self.emit(pcm16(samples+i,n))) return 0;
                    if (self.first_ms<0) self.first_ms=elapsed_ms(self.start);
                    self.samples+=n; i+=n;
                }
                return 1;
            } catch (...) { self.failed=true; return 0; }
        }
    };
public:
    explicit TtsRuntime(const fs::path& root) {
        auto model=asset(root,"model.onnx"), voices=asset(root,"voices.bin"), tokens=asset(root,"tokens.txt");
        auto lexicon=asset(root,"lexicon-us-en.txt")+","+asset(root,"lexicon-zh.txt");
        auto rules=asset(root,"date-zh.fst")+","+asset(root,"number-zh.fst")+","+asset(root,"phone-zh.fst");
        SherpaOnnxOfflineTtsConfig config{};
        config.model.num_threads=2; config.model.provider="cpu";
        config.model.kokoro.model=model.c_str(); config.model.kokoro.voices=voices.c_str();
        config.model.kokoro.tokens=tokens.c_str(); config.model.kokoro.lexicon=lexicon.c_str();
        config.model.kokoro.length_scale=1.0f;
        config.rule_fsts=rules.c_str(); config.max_num_sentences=1;
        config.silence_scale=0.2f;
        engine_.reset(SherpaOnnxCreateOfflineTts(&config));
        if (!engine_) throw std::runtime_error("failed to initialize Kokoro");
        sample_rate_=SherpaOnnxOfflineTtsSampleRate(engine_.get());
        speakers_=SherpaOnnxOfflineTtsNumSpeakers(engine_.get());
        if (sample_rate_<=0 || speakers_<=0) throw std::runtime_error("invalid TTS model metadata");
    }
    Json info() const override {
        return {{"backend","sherpa-onnx"},{"model","Kokoro-v1.0-zh-en"},{"device","cpu"},
            {"threads",2},{"sample_rate",sample_rate_},{"speakers",speakers_},
            {"delivery","sentence_callback_pcm"},{"model_native_streaming",false}};
    }
    Result generate(const Request& r, const Emit& emit) override {
        auto text=r.body.at("input").get<std::string>();
        auto speed=r.body.value("speed",1.0);
        auto sid=r.body.value("voice",2);
        if (text.empty() || text.size()>600 || !std::isfinite(speed) || speed<0.6 || speed>1.6 || sid<0 || sid>=speakers_)
            throw std::invalid_argument("invalid TTS text, speed or voice");
        Result result;
        if (stopped(r)) { result.outcome="cancelled"; return result; }
        auto begin=Clock::now();
        Callback cb{r,emit,begin,0,-1,false,sample_rate_};
        SherpaOnnxGenerationConfig config{};
        config.sid=sid; config.speed=static_cast<float>(speed); config.silence_scale=0.2f;
        using Audio=std::unique_ptr<const SherpaOnnxGeneratedAudio,decltype(&SherpaOnnxDestroyOfflineTtsGeneratedAudio)>;
        Audio audio(SherpaOnnxOfflineTtsGenerateWithConfig(engine_.get(),text.c_str(),&config,Callback::deliver,&cb),
                    SherpaOnnxDestroyOfflineTtsGeneratedAudio);
        if (cb.failed) throw std::runtime_error("TTS returned invalid waveform");
        if (stopped(r)) { result.outcome="cancelled"; return result; }
        if (!audio || audio->n<=0 || audio->sample_rate!=sample_rate_) throw std::runtime_error("TTS generated no valid audio");
        if (cb.samples==0 && !Callback::deliver(audio->samples,audio->n,1.0f,&cb)) {
            result.outcome="cancelled"; return result;
        }
        result.timings={{"generation_ms",elapsed_ms(begin)},{"first_pcm_ms",cb.first_ms}};
        result.details={{"audio_seconds",static_cast<double>(cb.samples)/sample_rate_},{"samples_sent",cb.samples},{"sample_rate",sample_rate_}};
        if (cb.samples!=static_cast<std::size_t>(audio->n)) result.outcome="cancelled";
        return result;
    }
};
}
std::unique_ptr<Runtime> make_asr_runtime(const RuntimeConfig& c) { return std::make_unique<AsrRuntime>(c.asr_dir); }
std::unique_ptr<Runtime> make_tts_runtime(const RuntimeConfig& c) { return std::make_unique<TtsRuntime>(c.tts_dir); }
}
