#include "kvharbor/serving/runtime.hpp"

#include <fstream>
#include <iostream>
#include <stdexcept>

using namespace kvharbor::serving;

int main(int argc, char** argv) try {
    RuntimeConfig config;
    std::string input, output;
    int warmup=1, repeat=1;
    bool fake=false;
    for (int i=1;i<argc;++i) {
        std::string arg=argv[i];
        auto value=[&] { if (++i>=argc) throw std::invalid_argument("missing option value"); return std::string(argv[i]); };
        if (arg=="--model") config.model=value();
        else if (arg=="--model-id") config.model_id=value();
        else if (arg=="--context") config.context=std::stoi(value());
        else if (arg=="--threads") config.threads=std::stoi(value());
        else if (arg=="--gpu-layers") config.gpu_layers=std::stoi(value());
        else if (arg=="--max-output-rows") {
            const auto rows=value();
            if (rows!="0" && rows!="1") throw std::invalid_argument("--max-output-rows requires 0 or 1");
            config.max_output_rows=rows=="1"?1:0;
        }
        else if (arg=="--reuse-context") config.reuse_context=true;
        else if (arg=="--sampling") config.sampling=parse_sampling_mode(value());
        else if (arg=="--input") input=value();
        else if (arg=="--output") output=value();
        else if (arg=="--repeat") repeat=std::stoi(value());
        else if (arg=="--warmup") warmup=std::stoi(value());
        else if (arg=="--test-backend") fake=true;
        else throw std::invalid_argument("unknown option: "+arg);
    }
    if ((!fake && config.model.empty()) || input.empty() || output.empty() || warmup<0 || repeat<1)
        throw std::invalid_argument("requires --model, --input and --output; --reuse-context enables reuse");
    std::ifstream jobs(input);
    if (!jobs) throw std::runtime_error("cannot read workload");
    std::vector<Json> rows;
    for (std::string line; std::getline(jobs,line);) if (!line.empty()) rows.push_back(Json::parse(line));
    if (rows.empty()) throw std::invalid_argument("empty workload");
    auto factory=make_factory(config,fake);
    auto runtime=factory->worker(Task::llm);
    std::ofstream out(output);
    if (!out) throw std::runtime_error("cannot write result");
    auto invoke=[&](const Json& body, std::string id, bool measured) {
        Request r;
        r.body=body; r.id=std::move(id); r.deadline=Clock::now()+std::chrono::minutes(3);
        auto start=Clock::now();
        double ttft=-1.0;
        std::string text;
        auto res=runtime->generate(r,[&](std::string data) {
            if (ttft<0) ttft=elapsed_ms(start);
            auto chunk=Json::parse(data.substr(6));
            text += chunk.at("choices").at(0).at("delta").at("content").get<std::string>();
            return true;
        });
        Json row={{"id",r.id},{"measured",measured},{"outcome",res.outcome},{"error",res.error},
            {"runtime",runtime->info()},{"ttft_ms",ttft},{"wall_ms",elapsed_ms(start)},
            {"timings",res.timings},{"usage",res.usage},{"details",res.details},{"text",text}};
        out<<row.dump()<<'\n'<<std::flush;
        if (res.outcome!="completed") throw std::runtime_error("generation did not complete");
    };
    for (int i=0;i<warmup;++i) invoke(rows[i%rows.size()],"warmup-"+std::to_string(i),false);
    for (int run=0;run<repeat;++run) for (std::size_t i=0;i<rows.size();++i)
        invoke(rows[i],std::to_string(run)+"-"+std::to_string(i),true);
    return 0;
} catch (const std::exception& error) {
    std::cerr<<"runtime benchmark: "<<error.what()<<'\n';
    return 1;
}
