#include "kvharbor/serving/runtime.hpp"
#include <stdexcept>
#include <array>
#include <algorithm>
#include <limits>

using namespace kvharbor::serving;

void require(bool pass) { if (!pass) throw std::runtime_error("serving core check failed"); }

int main() {
    require(greedy_argmax(std::array{-4.0f,-1.0f,-1.0f,-9.0f})==1);
    const auto infinity=std::numeric_limits<float>::infinity();
    const auto nan=std::numeric_limits<float>::quiet_NaN();
    require(greedy_argmax(std::array{-infinity,infinity,infinity})==1);
    require(greedy_argmax(std::array{0.0f,-0.0f})==0);
    require(greedy_argmax(std::array{nan,10.0f,20.0f})==0);
    require(greedy_argmax(std::array{1.0f,nan,2.0f})==2);
    try { greedy_argmax({}); require(false); } catch (const std::invalid_argument&) {}
    try { parse_sampling_mode("invalid"); require(false); } catch (const std::invalid_argument&) {}
    // Exercise vector-lane ties, unaligned spans and every short scalar-tail size.
    std::vector<float> tied(34,-1.0f);
    tied[8]=5.0f;tied[9]=5.0f;tied[33]=5.0f;
    require(greedy_argmax(std::span<const float>(tied).subspan(1))==7);
    tied[33]=6.0f;
    require(greedy_argmax(std::span<const float>(tied).subspan(1))==32);
    tied[18]=nan;tied[19]=infinity;tied[28]=infinity;
    require(greedy_argmax(std::span<const float>(tied).subspan(1))==18);
    tied[1]=nan;
    require(greedy_argmax(std::span<const float>(tied).subspan(1))==0);
    std::uint32_t seed=42;
    for (std::size_t size=1;size<=257;++size) {
        std::vector<float> data(size+1);
        for (auto& value:data) { seed=seed*1664525u+1013904223u;value=static_cast<float>(seed%997)-498.0f; }
        auto values=std::span<const float>(data).subspan(1);
        require(greedy_argmax(values)==std::max_element(values.begin(),values.end())-values.begin());
    }

    std::string pending="\xe4\xbd";
    require(take_utf8(pending).empty());
    pending+="\xa0" "A";
    require(take_utf8(pending)=="你A" && pending.empty());
    pending="\xe4";
    require(take_utf8(pending,true)=="\xef\xbf\xbd" && pending.empty());
    try { pending="\xed\xa0\x80"; take_utf8(pending); require(false); }
    catch (const std::runtime_error& e) { require(std::string(e.what())=="invalid UTF-8 scalar"); }

    std::string wav="RIFF";
    auto append=[&](std::uint32_t v,int bytes) { while (bytes--) { wav.push_back(static_cast<char>(v&255)); v>>=8; } };
    append(40,4); wav+="WAVEfmt "; append(16,4); append(1,2); append(1,2);
    append(16000,4); append(32000,4); append(2,2); append(16,2); wav+="data"; append(4,4);
    append(0x8000,2); append(0x7fff,2);
    int rate=0;
    auto samples=read_pcm16_wav(wav,rate);
    require(rate==16000 && samples.size()==2 && samples[0]==-1.0f && samples[1]>0.99f);
    require(pcm16(samples.data(),samples.size()).substr(0,2)==wav.substr(44,2));
    try { read_pcm16_wav(wav.substr(0,wav.size()-1),rate); require(false); }
    catch (const std::invalid_argument&) {}
}
