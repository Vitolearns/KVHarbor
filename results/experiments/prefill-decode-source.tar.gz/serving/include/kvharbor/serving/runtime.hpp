#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <span>
#include <string_view>
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

namespace kvharbor::serving {
using Json = nlohmann::json;
using Clock = std::chrono::steady_clock;
using Emit = std::function<bool(std::string)>;

enum class Task { llm, asr, tts };
const char* name(Task task);

// The legacy sampler materializes candidates per token. The chain sampler reuses its buffer.
// direct scans borrowed logits; backend uses the pinned engine's sampler graph.
enum class SamplingMode { legacy, chain, direct, backend };
const char* name(SamplingMode mode);
SamplingMode parse_sampling_mode(std::string_view value);
// Match the reference greedy sampler: first maximum, including its NaN behavior.
std::int32_t greedy_argmax(std::span<const float> logits);
const char* greedy_implementation();

struct Request {
    Task task = Task::llm;
    std::string id;
    Json body;
    std::string audio;
    Clock::time_point received = Clock::now();
    Clock::time_point deadline = received + std::chrono::seconds(60);
    std::shared_ptr<std::atomic<bool>> cancelled = std::make_shared<std::atomic<bool>>(false);
};

struct Result {
    std::string outcome = "completed";
    std::string error;
    Json usage = Json::object();
    Json timings = Json::object();
    Json details = Json::object();
};

enum class EngineSchedule { off, fifo, decode_first };

struct RuntimeConfig {
    std::string model;
    std::string model_id = "Qwen3.8-27B-Q4_K_M";
    int context = 2048;
    int threads = 4;
    int gpu_layers = 99;
    int batch = 512;
    std::uint32_t max_output_rows = 0;
    bool reuse_context = false;
    SamplingMode sampling = SamplingMode::direct;
    std::string asr_dir;
    std::string tts_dir;
    EngineSchedule engine_schedule = EngineSchedule::off;
    int prefill_chunk = 0;
};

class Runtime {
public:
    virtual ~Runtime() = default;
    virtual Result generate(const Request& request, const Emit& emit) = 0;
    virtual Json info() const = 0;
};

class Factory {
public:
    virtual ~Factory() = default;
    virtual std::unique_ptr<Runtime> worker(Task task) = 0;
    virtual bool available(Task task) const = 0;
};

std::unique_ptr<Factory> make_factory(const RuntimeConfig& config, bool test_backend);
std::unique_ptr<Factory> make_llama_factory(const RuntimeConfig& config);
std::unique_ptr<Runtime> make_asr_runtime(const RuntimeConfig& config);
std::unique_ptr<Runtime> make_tts_runtime(const RuntimeConfig& config);

// Preserves partial UTF-8 bytes across token boundaries; invalid complete input fails.
std::string take_utf8(std::string& pending, bool final = false);
std::string sse_content(const std::string& id, const std::string& text);
std::vector<float> read_pcm16_wav(const std::string& wav, int& sample_rate);
std::string pcm16(const float* samples, std::size_t count);
double elapsed_ms(Clock::time_point begin, Clock::time_point end = Clock::now());
}
