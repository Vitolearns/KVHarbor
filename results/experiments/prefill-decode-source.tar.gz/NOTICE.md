# Notice

KVHarbor contributions covered by the repository license use the PolyForm Noncommercial License 1.0.0. [License](LICENSE)

The prior distribution credited the inherited code to 知识星球「奔跑中cpp / c++」 and directed requests for commercial use to its rights holder. Third-party dependencies and model weights follow the terms of their respective distributions.

## 许可与来源

KVHarbor 中适用仓库许可证的贡献采用 PolyForm Noncommercial License 1.0.0。[许可原文](LICENSE)
