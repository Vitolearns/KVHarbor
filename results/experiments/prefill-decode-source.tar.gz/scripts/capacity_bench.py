#!/usr/bin/env python3
"""Measure live KVHarbor HTTP/SSE capacity and recovery after a short burst."""

import argparse
import hashlib
import json
import math
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

STREAM_BENCH = Path(__file__).with_name("stream_bench.py")
WORKLOAD = Path(__file__).resolve().parents[1] / "benchmarks/kvharbor_text_mixed.jsonl"
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def percentiles(values):
    if not values:
        return {"p50": None, "p95": None, "p99": None}
    values = sorted(values)
    return {name: values[math.ceil(len(values) * q) - 1]
            for name, q in (("p50", .5), ("p95", .95), ("p99", .99))}


def request_outcome(row):
    status = row.get("http_status")
    if status == 429:
        return "rejected"
    if status in (408, 504) or any(
        word in str(row.get(field, "")).lower()
        for field in ("outcome", "finish_reason", "error")
        for word in ("timeout", "timed out", "deadline")
    ):
        return "timeout"
    if status == 200 and row.get("done"):
        return "completed"
    return "failed"


def project(raw, args):
    outcome = dict.fromkeys(("completed", "rejected", "timeout", "failed"), 0)
    clean = []
    for row in raw["requests"]:
        label = request_outcome(row)
        outcome[label] += 1
        usage = row.get("usage") or {}
        tokens = usage.get("completion_tokens")
        ttft = row.get("ttft_ms")
        tpot = row.get("tpot_ms")
        meets_slo = (label == "completed" and ttft is not None and ttft <= args.ttft_ms
                     and ((tpot is not None and tpot <= args.tpot_ms)
                          or (tpot is None and tokens in (0, 1))))
        clean.append({
            "case": row.get("case"), "group": row.get("group"), "outcome": label,
            "http_status": row.get("http_status"), "ttft_ms": ttft, "tpot_ms": tpot,
            "e2e_ms": row.get("e2e_ms"), "completed_tokens": tokens,
            "prompt_tokens": usage.get("prompt_tokens"), "meets_slo": meets_slo,
            "output_sha256": row.get("output_sha256"),
        })
    passed = sum(row["meets_slo"] for row in clean)
    elapsed = raw["summary"]["measurement_s"]
    completed = [row for row in clean if row["outcome"] == "completed"]
    return {
        "offered": len(clean), "seconds": elapsed, "outcomes": outcome,
        "slo_compliant": passed, "goodput_rps": passed / elapsed,
        "output_tokens_per_s": sum(row["completed_tokens"] or 0 for row in completed) / elapsed,
        **{metric: percentiles([r[metric] for r in completed if r[metric] is not None])
           for metric in ("ttft_ms", "tpot_ms", "e2e_ms")},
        "requests": clean,
    }


def endpoint(args, name):
    with OPENER.open(f"{args.url.rstrip('/')}/{name}", timeout=3) as response:
        return json.load(response)


def idle_state(args):
    start = time.monotonic()
    while True:
        raw = endpoint(args, "state")
        state = {key: raw[key] for key in ("active", "accepted", "slot_releases")}
        state["terminal"] = sum(raw["outcomes"].values())
        if (state["active"] == 0 and state["accepted"] == state["terminal"]
                and state["slot_releases"] <= state["terminal"]):
            return state, (time.monotonic() - start) * 1000
        if time.monotonic() - start >= args.drain_seconds:
            raise RuntimeError("Requests did not drain or the admission ledger did not balance")
        time.sleep(.05)


def replay(args, name, count, rate, arrival, seed):
    out = args.output_dir / f"{name}.raw.json"
    command = [
        sys.executable, str(STREAM_BENCH), "--base-url", args.url, "--model", args.model,
        "--workload", str(args.workload), "--output", str(out),
        "--requests", str(count), "--concurrency", str(args.concurrency),
        "--rate", str(rate), "--arrival", arrival, "--seed", str(seed),
        "--timeout", str(args.client_timeout),
    ]
    with (args.output_dir / f"{name}.client.log").open("w") as log:
        subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
    return {"seed": seed, "offered_rps": rate, "arrival": arrival,
            **project(json.loads(out.read_bytes()), args)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8080")
    parser.add_argument("--model", required=True)
    parser.add_argument("--workload", type=Path, default=WORKLOAD)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--rates", type=float, nargs="+", default=[.4, .8, 1.6])
    parser.add_argument("--requests", type=int, default=24)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--concurrency", type=int, default=24)
    parser.add_argument("--client-timeout", type=float, default=20)
    parser.add_argument("--drain-seconds", type=float, default=30)
    parser.add_argument("--ttft-ms", type=float, default=2000)
    parser.add_argument("--tpot-ms", type=float, default=75)
    parser.add_argument("--burst-count", type=int, default=24)
    args = parser.parse_args()
    positive = [*args.rates, args.requests, args.repeats, args.concurrency,
                args.client_timeout, args.drain_seconds, args.ttft_ms, args.tpot_ms]
    if any(not math.isfinite(value) or value <= 0 for value in positive) or args.burst_count < 0:
        parser.error("Run parameters must be finite and positive. A burst count of zero skips bursts.")
    if endpoint(args, "health").get("status") != "ok":
        raise RuntimeError("KVHarbor health check failed")
    args.output_dir.mkdir(parents=True)
    report = {
        "schema_version": 1, "model_id": args.model,
        "workload_sha256": hashlib.sha256(args.workload.read_bytes()).hexdigest(),
        "slo_ms": {"ttft": args.ttft_ms, "tpot": args.tpot_ms},
        "client_concurrency": args.concurrency, "client_timeout_seconds": args.client_timeout,
        "runs": [], "overload_recovery": [],
    }
    initial, _ = idle_state(args)
    warmup = replay(args, "warmup", 3, 0, "fixed", 40)
    if warmup["outcomes"]["completed"] != 3:
        raise RuntimeError("Expected three successful warm-up requests")
    idle_state(args)

    for repeat in range(args.repeats):
        # Reverse the rates every other repeat to reduce time-of-run bias.
        indices = range(len(args.rates)) if repeat % 2 == 0 else reversed(range(len(args.rates)))
        for index in indices:
            rate = args.rates[index]
            name = f"repeat-{repeat + 1}-rate-{index + 1}"
            res = replay(args, name, args.requests, rate, "poisson", 41 + repeat)
            idle_state(args)
            report["runs"].append({"repeat": repeat + 1, **res})
            print(f"{name} done: {res['outcomes']}", flush=True)

    if args.burst_count:
        for repeat in range(args.repeats):
            before, _ = idle_state(args)
            burst = replay(args, f"burst-{repeat + 1}", args.burst_count, 100, "fixed", 41 + repeat)
            after, drain_ms = idle_state(args)
            recovery = replay(args, f"recovery-{repeat + 1}", 3, 0, "fixed", 40)
            final, _ = idle_state(args)
            report["overload_recovery"].append({
                "burst": burst, "recovery": recovery, "drain_poll_ms_after_client_complete": drain_ms,
                "accepted_in_burst": after["accepted"] - before["accepted"],
                "released_in_burst": after["slot_releases"] - before["slot_releases"],
                "terminal_in_burst": after["terminal"] - before["terminal"],
                "accepted_in_recovery": final["accepted"] - after["accepted"],
                "released_in_recovery": final["slot_releases"] - after["slot_releases"],
            })
            if not burst["outcomes"]["rejected"] or recovery["outcomes"]["completed"] != 3:
                raise RuntimeError("Expected overload rejection and three successful recovery requests")
            print(f"burst-{repeat + 1} recovered: {burst['outcomes']}", flush=True)
    final, _ = idle_state(args)
    report["ledger"] = {key: final[key] - initial[key] for key in final}
    (args.output_dir / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
